from django.contrib import admin
from .models import Post  # Import your Post model

# Register the Post model so it shows in admin
admin.site.register(Post)